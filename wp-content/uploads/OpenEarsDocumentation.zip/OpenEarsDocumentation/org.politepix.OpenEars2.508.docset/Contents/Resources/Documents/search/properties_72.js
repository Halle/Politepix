var searchData=
[
  ['removingnoise',['removingNoise',['../interface_o_e_pocketsphinx_controller.html#a29aa7e24c3bfb7d8feb20b50ac17ff87',1,'OEPocketsphinxController']]],
  ['removingsilence',['removingSilence',['../interface_o_e_pocketsphinx_controller.html#af8e813e143e2de78133e852178885e9e',1,'OEPocketsphinxController']]],
  ['returnnbest',['returnNbest',['../interface_o_e_pocketsphinx_controller.html#a490f41c6beea62a5e082a837e21d12ac',1,'OEPocketsphinxController']]],
  ['returnnullhypotheses',['returnNullHypotheses',['../interface_o_e_pocketsphinx_controller.html#acf9c8da5abffadb05a1cc431d5a3b396',1,'OEPocketsphinxController']]]
];
