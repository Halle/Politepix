var searchData=
[
  ['nbestnumber',['nBestNumber',['../interface_o_e_pocketsphinx_controller.html#a63d2af7edce07a70cadcaabed0198277',1,'OEPocketsphinxController']]]
];
