var searchData=
[
  ['flitedidfinishspeaking',['fliteDidFinishSpeaking',['../protocol_o_e_events_observer_delegate-p.html#acc723ed134389dbef50cc757d093793f',1,'OEEventsObserverDelegate-p']]],
  ['flitedidstartspeaking',['fliteDidStartSpeaking',['../protocol_o_e_events_observer_delegate-p.html#ad49a24546249f9b584cc6fd4df8883a5',1,'OEEventsObserverDelegate-p']]]
];
