var searchData=
[
  ['removingnoise',['removingNoise',['../interface_o_e_pocketsphinx_controller.html#a29aa7e24c3bfb7d8feb20b50ac17ff87',1,'OEPocketsphinxController']]],
  ['removingsilence',['removingSilence',['../interface_o_e_pocketsphinx_controller.html#af8e813e143e2de78133e852178885e9e',1,'OEPocketsphinxController']]],
  ['requestmicpermission',['requestMicPermission',['../interface_o_e_pocketsphinx_controller.html#a8f3be7cadb19e972cd5ddf6564a3a649',1,'OEPocketsphinxController']]],
  ['resumerecognition',['resumeRecognition',['../interface_o_e_pocketsphinx_controller.html#a65c361b496f1c5a7972e7b72874822fd',1,'OEPocketsphinxController']]],
  ['returnnbest',['returnNbest',['../interface_o_e_pocketsphinx_controller.html#a490f41c6beea62a5e082a837e21d12ac',1,'OEPocketsphinxController']]],
  ['returnnullhypotheses',['returnNullHypotheses',['../interface_o_e_pocketsphinx_controller.html#acf9c8da5abffadb05a1cc431d5a3b396',1,'OEPocketsphinxController']]],
  ['runrecognitiononwavfileatpath_3ausinglanguagemodelatpath_3adictionaryatpath_3aacousticmodelatpath_3alanguagemodelisjsgf_3a',['runRecognitionOnWavFileAtPath:usingLanguageModelAtPath:dictionaryAtPath:acousticModelAtPath:languageModelIsJSGF:',['../interface_o_e_pocketsphinx_controller.html#ad41254c2577113d59160003fc4575092',1,'OEPocketsphinxController']]]
];
