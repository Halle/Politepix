var searchData=
[
  ['micpermissioncheckcompleted_3a',['micPermissionCheckCompleted:',['../protocol_o_e_events_observer_delegate-p.html#a02b083a3f41e2c1484f003e1a4f3e550',1,'OEEventsObserverDelegate-p']]],
  ['micpermissionisgranted',['micPermissionIsGranted',['../interface_o_e_pocketsphinx_controller.html#ad96672fe1206b9aaaf9bb66c1ab536c3',1,'OEPocketsphinxController']]]
];
