var searchData=
[
  ['islistening',['isListening',['../interface_o_e_pocketsphinx_controller.html#aaee56e507ae7cef6e8b86f1004b22155',1,'OEPocketsphinxController']]],
  ['issuspended',['isSuspended',['../interface_o_e_pocketsphinx_controller.html#a2c021aad050264ab9b9c6ecc88134dab',1,'OEPocketsphinxController']]]
];
