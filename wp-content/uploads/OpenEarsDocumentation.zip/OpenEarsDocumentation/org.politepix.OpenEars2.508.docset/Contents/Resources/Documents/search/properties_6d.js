var searchData=
[
  ['micpermissionisgranted',['micPermissionIsGranted',['../interface_o_e_pocketsphinx_controller.html#ad96672fe1206b9aaaf9bb66c1ab536c3',1,'OEPocketsphinxController']]]
];
