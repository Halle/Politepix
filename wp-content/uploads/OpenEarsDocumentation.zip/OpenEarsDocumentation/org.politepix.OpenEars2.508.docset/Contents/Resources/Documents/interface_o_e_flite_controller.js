var interface_o_e_flite_controller =
[
    [ "say:withVoice:", "interface_o_e_flite_controller.html#a0e6d5ecef2fe0dc05b6cd819045ffae4", null ],
    [ "_backgroundQueue", "interface_o_e_flite_controller.html#a993bb7bfbdf6368025a6a31fccd33bd8", null ],
    [ "fliteOutputLevel", "interface_o_e_flite_controller.html#ad292a77c964b824481be01b6cb255968", null ],
    [ "duration_stretch", "interface_o_e_flite_controller.html#a8ade45f74ea1525066166726f4fd4b30", null ],
    [ "target_mean", "interface_o_e_flite_controller.html#a08c4169b8dbe90c22439fa35aa36af03", null ],
    [ "target_stddev", "interface_o_e_flite_controller.html#a898360f06cf5eae80a51c3f7c00a0bab", null ],
    [ "userCanInterruptSpeech", "interface_o_e_flite_controller.html#a494d5c87069ac090508db0cb331a5d20", null ]
];