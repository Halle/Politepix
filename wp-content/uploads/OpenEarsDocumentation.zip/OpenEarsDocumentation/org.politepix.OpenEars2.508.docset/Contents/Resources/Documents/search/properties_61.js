var searchData=
[
  ['audiomode',['audioMode',['../interface_o_e_pocketsphinx_controller.html#aa9f915523739fbcc156ebf7f2cfb500b',1,'OEPocketsphinxController']]]
];
