var searchData=
[
  ['delegate',['delegate',['../interface_o_e_events_observer.html#ac3dd2aa74cc4c8ef5e9ef3ce7961f36e',1,'OEEventsObserver']]],
  ['disablebluetooth',['disableBluetooth',['../interface_o_e_pocketsphinx_controller.html#aa7136ab98eb28b0ae4cf9716fa9dc791',1,'OEPocketsphinxController']]],
  ['disablemixing',['disableMixing',['../interface_o_e_pocketsphinx_controller.html#a4a0c4f96210ac841f8714adb1d79c7d3',1,'OEPocketsphinxController']]],
  ['disablepreferredbuffersize',['disablePreferredBufferSize',['../interface_o_e_pocketsphinx_controller.html#aae3a05b57f5580d99eb44f9a10f9ce72',1,'OEPocketsphinxController']]],
  ['disablepreferredchannelnumber',['disablePreferredChannelNumber',['../interface_o_e_pocketsphinx_controller.html#adaf2982ff4824c0ea357c3fe014998d4',1,'OEPocketsphinxController']]],
  ['disablepreferredsamplerate',['disablePreferredSampleRate',['../interface_o_e_pocketsphinx_controller.html#a173f04c7f0860fe0035add91cf091ba6',1,'OEPocketsphinxController']]],
  ['disablesessionresetswhilestopped',['disableSessionResetsWhileStopped',['../interface_o_e_pocketsphinx_controller.html#a89bb40ff64bae2a2f212a9e63083228c',1,'OEPocketsphinxController']]],
  ['duration_5fstretch',['duration_stretch',['../interface_o_e_flite_controller.html#a8ade45f74ea1525066166726f4fd4b30',1,'OEFliteController']]]
];
