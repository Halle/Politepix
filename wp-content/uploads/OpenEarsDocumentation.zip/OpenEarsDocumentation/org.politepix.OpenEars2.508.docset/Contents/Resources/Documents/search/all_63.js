var searchData=
[
  ['changelanguagemodeltofile_3awithdictionary_3a',['changeLanguageModelToFile:withDictionary:',['../interface_o_e_pocketsphinx_controller.html#a012fa512c1d6d62f3765153b64c1ab2d',1,'OEPocketsphinxController']]]
];
