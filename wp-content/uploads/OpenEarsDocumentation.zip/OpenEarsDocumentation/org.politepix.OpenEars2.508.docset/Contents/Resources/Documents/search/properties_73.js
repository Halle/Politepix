var searchData=
[
  ['secondsofsilencetodetect',['secondsOfSilenceToDetect',['../interface_o_e_pocketsphinx_controller.html#a604e7b2b9ac770732b9a493f79cc95c2',1,'OEPocketsphinxController']]]
];
