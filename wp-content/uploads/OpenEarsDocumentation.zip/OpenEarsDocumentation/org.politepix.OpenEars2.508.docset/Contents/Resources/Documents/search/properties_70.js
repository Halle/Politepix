var searchData=
[
  ['pathtotestfile',['pathToTestFile',['../interface_o_e_pocketsphinx_controller.html#a9d49f7b98c1d34ea934f02778d455072',1,'OEPocketsphinxController']]],
  ['pocketsphinxinputlevel',['pocketsphinxInputLevel',['../interface_o_e_pocketsphinx_controller.html#add7c7c04ec66355625635cd59ab1ee5d',1,'OEPocketsphinxController']]]
];
