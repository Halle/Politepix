var searchData=
[
  ['requestmicpermission',['requestMicPermission',['../interface_o_e_pocketsphinx_controller.html#a8f3be7cadb19e972cd5ddf6564a3a649',1,'OEPocketsphinxController']]],
  ['resumerecognition',['resumeRecognition',['../interface_o_e_pocketsphinx_controller.html#a65c361b496f1c5a7972e7b72874822fd',1,'OEPocketsphinxController']]],
  ['runrecognitiononwavfileatpath_3ausinglanguagemodelatpath_3adictionaryatpath_3aacousticmodelatpath_3alanguagemodelisjsgf_3a',['runRecognitionOnWavFileAtPath:usingLanguageModelAtPath:dictionaryAtPath:acousticModelAtPath:languageModelIsJSGF:',['../interface_o_e_pocketsphinx_controller.html#ad41254c2577113d59160003fc4575092',1,'OEPocketsphinxController']]]
];
