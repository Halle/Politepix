var searchData=
[
  ['target_5fmean',['target_mean',['../interface_o_e_flite_controller.html#a08c4169b8dbe90c22439fa35aa36af03',1,'OEFliteController']]],
  ['target_5fstddev',['target_stddev',['../interface_o_e_flite_controller.html#a898360f06cf5eae80a51c3f7c00a0bab',1,'OEFliteController']]]
];
