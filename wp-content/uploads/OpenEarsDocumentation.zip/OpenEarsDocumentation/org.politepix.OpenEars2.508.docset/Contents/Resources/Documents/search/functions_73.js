var searchData=
[
  ['say_3awithvoice_3a',['say:withVoice:',['../interface_o_e_flite_controller.html#a0e6d5ecef2fe0dc05b6cd819045ffae4',1,'OEFliteController']]],
  ['setactive_3aerror_3a',['setActive:error:',['../interface_o_e_pocketsphinx_controller.html#a85b10d89bb3451359e35db79164ecd63',1,'OEPocketsphinxController']]],
  ['sharedinstance',['sharedInstance',['../interface_o_e_pocketsphinx_controller.html#a460a026fd94a2de3ada3dda18645e8a3',1,'OEPocketsphinxController']]],
  ['startlisteningwithlanguagemodelatpath_3adictionaryatpath_3aacousticmodelatpath_3alanguagemodelisjsgf_3a',['startListeningWithLanguageModelAtPath:dictionaryAtPath:acousticModelAtPath:languageModelIsJSGF:',['../interface_o_e_pocketsphinx_controller.html#a8caa05414a87c3660f52c1a418350a03',1,'OEPocketsphinxController']]],
  ['startopenearslogging',['startOpenEarsLogging',['../interface_o_e_logging.html#ae31a282772caeaa5b45dc920abca7be9',1,'OELogging']]],
  ['stoplistening',['stopListening',['../interface_o_e_pocketsphinx_controller.html#a53e3987aa23533a86f457dde1190eb0a',1,'OEPocketsphinxController']]],
  ['suspendrecognition',['suspendRecognition',['../interface_o_e_pocketsphinx_controller.html#a5cd8225983e01287aa38bc6d10520594',1,'OEPocketsphinxController']]]
];
