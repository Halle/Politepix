var searchData=
[
  ['legacy3rdpassmode',['legacy3rdPassMode',['../interface_o_e_pocketsphinx_controller.html#a60e5a4fabf5f30cb1a994c101121b7b3',1,'OEPocketsphinxController']]]
];
