var interface_o_e_events_observer =
[
    [ "delegate", "interface_o_e_events_observer.html#ac3dd2aa74cc4c8ef5e9ef3ce7961f36e", null ]
];