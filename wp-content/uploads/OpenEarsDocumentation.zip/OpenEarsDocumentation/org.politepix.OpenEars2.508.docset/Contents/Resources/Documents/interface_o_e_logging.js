var interface_o_e_logging =
[
    [ "startOpenEarsLogging", "interface_o_e_logging.html#ae31a282772caeaa5b45dc920abca7be9", null ]
];